<div>

    <!-- Validation Errors -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <form wire:submit.prevent="onCreateSite">
        <div class="form-group">
            <label for="title" class="form-control-label"><?php echo e(__('Title')); ?></label>
            <input class="form-control" type="text" id="title" wire:model="title">
        </div>

        <div class="form-group">
            <label for="url" class="form-control-label"><?php echo e(__('Link')); ?></label>
            <select class="form-control" wire:model="link">
                <option value selected style="display:none;"><?php echo e(__('Choose a page...')); ?></option>
                <?php if( !empty($pages) ): ?>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($page['slug']); ?>"><?php echo e(__( $page['slug'] )); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </select>
        </div>

        <div class="form-group">
            <label for="site-image" class="form-label"><?php echo e(__('Image')); ?></label>
            <div class="input-group">
                <span class="input-group-btn">
                    <a id="site-image" data-input="thumbnail" class="btn btn-primary mb-0 site-image">
                        <i class="fa fa-picture-o"></i> <?php echo e(__('Choose')); ?>

                    </a>
                </span>
                <input id="thumbnail" class="form-control ps-2" type="text" wire:model="image">
            </div>
        </div>

        <div class="float-end mt-3">
            <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
            <button type="submit" class="btn bg-gradient-primary">
                <span>
                    <div wire:loading wire:target="onCreateSite">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                    <span><?php echo e(__('Create')); ?></span>
                </span>
            </button>
        </div>
    </form>

</div>

<script>
(function( $ ) {
    "use strict";

    document.addEventListener('livewire:load', function () {

        jQuery('.site-image').filemanager('image', {prefix: '<?php echo e(url('/')); ?>/filemanager'});

        jQuery('input#thumbnail').change(function() { 
            window.livewire.emit('onSetSiteImage', this.value)
        });

    });
    
})( jQuery );
</script>
<?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/settings/supported-sites/create.blade.php ENDPATH**/ ?>