<div>
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.frontend.navbar','data' => ['header' => $header,'homeTitle' => $homeTitle,'page' => $page,'menus' => $menus]]); ?>
<?php $component->withName('frontend.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($header),'homeTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($homeTitle),'page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page),'menus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menus)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

      <section>
        <div class="page-header section-height-100">
          <div class="container">
            <div class="row">
              <div class="col-xl-4 col-lg-5 col-md-7 d-flex flex-column mx-lg-0 mx-auto">
                <div class="card card-plain">
                  <div class="card-header pb-0 text-left">
                    <h4 class="font-weight-bolder"><?php echo e(__('Sign In')); ?></h4>
                    <p class="mb-0"><?php echo e(__('Enter your email and password to sign in')); ?></p>
                  </div>

                  <div class="card-body">

                    <!-- Validation Errors -->
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                    <form wire:submit.prevent="onLogin">
					
                      <div class="mb-3">
                        <input class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e(__('Email')); ?>" type="email" wire:model="email" required autofocus />
                      </div>
                      <div class="mb-3">
                        <input class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e(__('Password')); ?>" type="password" wire:model="password" required />
                      </div>
                      <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" wire:model="remember_me" id="remember_me">
                        <label class="form-check-label" for="remember_me"><?php echo e(__('Remember me')); ?></label>
                      </div>
                      <div class="text-center">
                        <button class="btn btn-lg bg-gradient-primary btn-lg w-100 mt-4 mb-0">
                          <div wire:loading wire:target="onLogin">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                          </div>
                          <?php echo e(__('Sign In')); ?></button>
                      </div>
                    </form>

                  </div>
                </div>
              </div>

              <div class="col-6 d-lg-flex d-none h-100 my-auto pe-0 position-absolute top-0 end-0 text-center justify-content-center flex-column">
                <div class="position-relative bg-gradient-primary h-100 m-3 px-7 border-radius-lg d-flex flex-column justify-content-center">
                  <img src="<?php echo e(asset('assets/img/shapes/pattern-lines.svg')); ?>" alt="pattern-lines" class="position-absolute opacity-4 start-0">
                  <div class="position-relative">
                    <img class="max-width-500 w-100 position-relative z-index-2" src="<?php echo e(asset('assets/img/illustrations/chat.png')); ?>">
                  </div>
                  <h4 class="mt-5 text-white font-weight-bolder"><?php echo e(__('Welcome back!')); ?></h4>
                  <p class="text-white"><?php echo e(__('Login with your email address and password to keep connected with us.')); ?></p>
                </div>
              </div>
              
            </div>
          </div>
        </div>
      </section>
</div>    <?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/login.blade.php ENDPATH**/ ?>