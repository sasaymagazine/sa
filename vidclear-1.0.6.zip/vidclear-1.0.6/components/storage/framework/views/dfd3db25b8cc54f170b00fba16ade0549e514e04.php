<div>

    <div class="card">
        <div class="card-body">

          <div class="alert alert-secondary text-white" role="alert">
              <strong><?php echo e(__('You are editing the :langNative version', ['langNative' => localization()->getSupportedLocales()[app()->getLocale()]->native()])); ?> (<a href="<?php echo e(localization()->getLocalizedURL(app()->getLocale(), route('home') . '/' . $slug, [], true)); ?>" class="text-light"><?php echo e(__('View page')); ?></a>).</strong>
          </div>

            <!-- Validation Errors -->
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            <form wire:submit.prevent="onEditPageTranslation">

                <div class="form-group">
                    <label for="content-title" class="form-label"><?php echo e(__('Title')); ?></label>
                    <input class="form-control <?php $__errorArgs = ['title.' . app()->getLocale()];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" wire:model="title.<?php echo e(app()->getLocale()); ?>" id="content-title" required>
                    <small><?php echo e(__('This is what will appear in the first line when this post shows up in the search results. It should be less than or equal to')); ?> <code><?php echo e(__('60 characters')); ?></code>.</small>
                </div>

                <div class="form-group">
                    <label for="subtitle" class="form-label"><?php echo e(__('Subtitle')); ?></label>
                    <div class="input-group mb-3">
                        <input class="form-control" type="text" wire:model="subtitle.<?php echo e(app()->getLocale()); ?>" id="subtitle">
                    </div>
                </div>

                <div class="form-group">
                    <label for="short-description" class="form-label"><?php echo e(__('Short description')); ?></label>
                    <input class="form-control" type="text" wire:model="short_description.<?php echo e(app()->getLocale()); ?>" id="short-description">
                    <small><?php echo e(__('This description will show up on search engines.')); ?></small>
                </div>

                <div class="form-group" wire:ignore>
                    <label for="description" class="form-label"><?php echo e(__('Description')); ?></label>
                    <textarea class="description" id="description" rows="15" wire:model="description.<?php echo e(app()->getLocale()); ?>"></textarea>
                </div>

                <div class="form-group">
                    <button class="btn bg-gradient-primary float-end">
                        <span>
                            <div wire:loading wire:target="onEditPageTranslation">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </div>
                            <span><?php echo e(__('Save Changes')); ?></span>
                        </span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>

<script src="<?php echo e(asset('components/public/vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>
<script>
(function( $ ) {
    "use strict";

    document.addEventListener('livewire:load', function () {

        tinymce.init({
            selector: '.description',
            setup: function (editor) {
                editor.on('init change', function () {
                    editor.save();
                });
                editor.on('change', function (e) {
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('description.<?php echo e(app()->getLocale()); ?>', editor.getContent());
                });
            },
            plugins: [
                'advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker',
                'searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking',
                'table emoticons template paste help'
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | lignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media code",
            file_picker_callback: function (callback, value, meta) {
                let x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
                let y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

                let type = 'image' === meta.filetype ? 'Images' : 'Files',
                    url  = '<?php echo e(url('/')); ?>/filemanager?editor=tinymce5&type=' + type;

                tinymce.activeEditor.windowManager.openUrl({
                    url : url,
                    title : 'Filemanager',
                    width : x * 0.8,
                    height : y * 0.8,
                    onMessage: (api, message) => {
                        callback(message.content);
                    }
                });
                //
            }
        });
		
		window.addEventListener('alert', event => {
			toastr[event.detail.type](event.detail.message);
		});
	
    });

})( jQuery );
</script><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/pages/translations/edit.blade.php ENDPATH**/ ?>