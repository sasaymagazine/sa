<div>

  <!-- Begin:Sites -->
    <div class="row">
        <div class="col-12">

            <button class="btn bg-gradient-info" data-bs-toggle="modal" data-bs-target="#addNewSite"><i class="fas fa-plus fa-fw"></i> <?php echo e(__('Add New Site')); ?></button>

            <div class="card">
              <div class="card-body">
                  <table class="table align-items-center">
                      <tbody>
                          <tr>
                              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Title')); ?></th>
                              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Link')); ?></th>
                              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Latest updates')); ?></th>
                              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Action')); ?></th>
                          </tr>

                            <?php if( !empty($sites) ): ?>

                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle">
                                            <div class="d-flex px-2 py-1">
                                                <div>
                                                    <img src="<?php echo e(($site['image']) ? $site['image'] : asset('assets/img/no-thumb.jpg')); ?>" class="avatar avatar-sm me-3">
                                                </div>
                                                <div class="d-flex align-items-center">
                                                    <h6 class="mb-0 text-xs"><?php echo e($site['title']); ?></h6>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="align-middle">
                                            <input class="form-control" type="text" value="<?php echo e(url('/') . '/' . $site['link']); ?>" readonly>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($site['updated_at']); ?></span>
                                        </td>
                                        <td class="align-middle w-25 py-3">
                                            <a class="btn btn-sm btn-info mb-0" title="<?php echo e(__('Edit')); ?>" wire:click="onShowEditSiteModal( <?php echo e($site['id']); ?> )"><i class="fas fa-edit fa-fw"></i> <?php echo e(__('Edit')); ?></a>
                                            <a class="btn btn-sm btn-danger mb-0" title="<?php echo e(__('Delete')); ?>" wire:click="onDeleteConfirmSite( <?php echo e($site['id']); ?> )"><i class="fas fa-trash fa-fw"></i> <?php echo e(__('Delete')); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>

                              <tr>
                                <td class="align-middle"><?php echo e(__('No record found')); ?></td>
                              </tr>

                            <?php endif; ?>

                      </tbody>
                  </table>

              </div>
            </div>

        </div>
    </div>
    <!-- End:Sites -->

    <!-- Begin::Add New Site -->
    <div class="modal fade" id="addNewSite" tabindex="-1" role="dialog" aria-labelledby="addNewSiteLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="addNewSiteModalLabel"><?php echo e(__('Add New Site')); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.supported-sites.create')->html();
} elseif ($_instance->childHasBeenRendered('VEKoCAd')) {
    $componentId = $_instance->getRenderedChildComponentId('VEKoCAd');
    $componentTag = $_instance->getRenderedChildComponentTagName('VEKoCAd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VEKoCAd');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.supported-sites.create');
    $html = $response->html();
    $_instance->logRenderedChild('VEKoCAd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          </div>

        </div>
      </div>
    </div>
    <!-- End::Add New Site -->

    <!-- Begin::Edit Site -->
    <div class="modal fade" id="editSite" tabindex="-1" role="dialog" aria-labelledby="editSiteLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editSiteModalLabel"><?php echo e(__('Edit Site')); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.supported-sites.edit')->html();
} elseif ($_instance->childHasBeenRendered('5iPDfaq')) {
    $componentId = $_instance->getRenderedChildComponentId('5iPDfaq');
    $componentTag = $_instance->getRenderedChildComponentTagName('5iPDfaq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5iPDfaq');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.supported-sites.edit');
    $html = $response->html();
    $_instance->logRenderedChild('5iPDfaq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          </div>

        </div>
      </div>
    </div>
    <!-- End::Edit Site -->

</div>

<script src="<?php echo e(asset('components/public/vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>
<script>
(function( $ ) {
    "use strict";

    document.addEventListener('livewire:load', function () {

        window.addEventListener('swal:modal', event => {

            const swalWithBootstrapButtons = Swal.mixin({
              customClass: {
                confirmButton: 'btn bg-gradient-success',
                cancelButton: 'btn bg-gradient-danger'
              },
              buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
              title: event.detail.title,
              text: event.detail.text,
              icon: event.detail.type,
              showCancelButton: true,
              confirmButtonText: "<?php echo e(__('Yes, delete it!')); ?>",
              cancelButtonText: "<?php echo e(__('Cancel')); ?>"
            }).then((result) => {
              if (result.isConfirmed) {
                window.livewire.emit('onDeleteSite', event.detail.id)
              }
            });
    
        });

        window.addEventListener('closeModal', event => {
            $('#' + event.detail.id).modal('hide');
        });

        window.addEventListener('showModal', event => {
            $('#' + event.detail.id).modal('show');
        });
            
        window.addEventListener('alert', event => {
            toastr[event.detail.type](event.detail.message);
        });

    });

})( jQuery );
</script><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/settings/supported-sites.blade.php ENDPATH**/ ?>