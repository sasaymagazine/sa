<?php switch( $advertisement->area4_align ):
    case ('left'): ?>
		<div class="area4 d-flex justify-content-start" style="margin:<?php echo e($advertisement->area4_margin); ?>px;">
			<?php echo $advertisement->area4; ?>

		</div>

    <?php break; ?>

    <?php case ('right'): ?>
		<div class="area4 d-flex justify-content-end" style="margin:<?php echo e($advertisement->area4_margin); ?>px;">
			<?php echo $advertisement->area4; ?>

		</div>
    <?php break; ?>

    <?php default: ?>
		<div class="area4 d-flex justify-content-center" style="margin:<?php echo e($advertisement->area4_margin); ?>px;">
			<?php echo $advertisement->area4; ?>

		</div>
<?php endswitch; ?><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/components/frontend/advertisement/area4.blade.php ENDPATH**/ ?>