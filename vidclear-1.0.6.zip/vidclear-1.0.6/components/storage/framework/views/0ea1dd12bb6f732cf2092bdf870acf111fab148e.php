<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo e(__('VidClear Dashboard')); ?></title>
	
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

    <!-- Pace -->
    <script src="<?php echo e(asset('assets/js/pace.min.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pace-theme-default.min.css')); ?>">
    
    <!-- Icons -->
    <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome.min.css')); ?>">

    <!-- Theme CSS -->
    <link type="text/css" href="<?php echo e(asset('assets/css/main.min.css')); ?>" rel="stylesheet">

    <!-- Custom -->
    <link type="text/css" href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
    
    <?php echo \Livewire\Livewire::styles(); ?>


</head>
<body>
	
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.login')->html();
} elseif ($_instance->childHasBeenRendered('J0cayrd')) {
    $componentId = $_instance->getRenderedChildComponentId('J0cayrd');
    $componentTag = $_instance->getRenderedChildComponentTagName('J0cayrd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('J0cayrd');
} else {
    $response = \Livewire\Livewire::mount('admin.login');
    $html = $response->html();
    $_instance->logRenderedChild('J0cayrd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    
    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.min.js')); ?>"></script>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/admin/login.blade.php ENDPATH**/ ?>