<div>

    <!-- Validation Errors -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    
	<form wire:submit.prevent="onUpdateSMTP" wire:ignore>
	
		<div class="card">
			<div class="card-body">
				<h6><?php echo e(__('SMTP Configuration Settings')); ?></h6>
				<hr>
				<table class="table settings">
					<tr>
						<td><label for="host" class="form-label"><?php echo e(__('Host')); ?></label></td>
						<td>
							<input id="host" class="form-control ms-auto" type="text" wire:model="host" placeholder="smtp.gmail.com">
							<small><?php echo e(__('Your mail server.')); ?></small>
						</td>
					</tr>

					<tr>
						<td><label for="port" class="form-label"><?php echo e(__('Port')); ?></label></td>
						<td>
							<input id="port" class="form-control ms-auto" type="text" wire:model="port" placeholder="587">
							<small><?php echo e(__('The port to your mail server.')); ?></small>
						</td>
					</tr>

					<tr>
						<td><label for="username" class="form-label"><?php echo e(__('Username')); ?></label></td>
						<td>
							<input id="username" class="form-control ms-auto" type="text" wire:model="username" placeholder="themeluxury@gmail.com">
							<small><?php echo e(__('The username to login to your mail server.')); ?></small>
						</td>
					</tr>

					<tr>
						<td><label for="password" class="form-label"><?php echo e(__('Password')); ?></label></td>
						<td>
							<input id="password" class="form-control ms-auto" type="password" wire:model="password" placeholder="hpnsegxygohzob">
							<small><?php echo e(__('The password to login to your mail server.')); ?></small>
						</td>
					</tr>

					<tr>
						<td><label for="encryption" class="form-label"><?php echo e(__('Encryption')); ?></label></td>
						<td>
							<input id="encryption" class="form-control ms-auto" type="text" wire:model="encryption" placeholder="tls">
							<small><?php echo e(__('For most servers')); ?> <code>ssl</code> or <code>tls</code> <?php echo e(__(' is the recommended option.')); ?></small>
						</td>
					</tr>

				</table>			

			</div>
		</div>

		<div class="form-group mt-4">
			<button class="btn bg-gradient-primary float-end">
				<span>
					<div wire:loading wire:target="onUpdateSMTP">
						<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					</div>
					<span><?php echo e(__('Save Changes')); ?></span>
				</span>
			</button>
		</div>

	</form>

</div>

<script>
(function( $ ) {
	"use strict";

	document.addEventListener('livewire:load', function () {
		
		window.addEventListener('alert', event => {
			toastr[event.detail.type](event.detail.message);
		});

	});

})( jQuery );
</script><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/settings/smtp.blade.php ENDPATH**/ ?>