<div>
    <!-- Validation Errors -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    
    <div class="row">
        <div class="col-12">

            <div class="position-relative pb-0">
                <button class="btn bg-gradient-info" data-bs-toggle="modal" data-bs-target="#addNewTranslation"><?php echo e(__('Add New Translation')); ?></button>
            </div>

            <div class="card shadow-lg mb-5">
                <div class="card-body">

              <div class="alert alert-secondary text-white" role="alert">
                  <strong><?php echo e(__('You are translating :langNative language.', ['langNative' => $lang_name])); ?></strong>
              </div>

                <!-- begin:Form Search -->
                <form id="formSearchTranslation">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control form-control-lg" wire:model="searchQuery" placeholder="<?php echo e(__('Search here...')); ?>">
                    </div>
                </form>
                <!-- end:Form Search -->

                    <div class="table-responsive">
                        <form wire:submit.prevent="onUpdateTranslation">
                            <div class="form-group">
                                <button class="btn bg-gradient-primary">
                                    <span>
                                        <div wire:loading wire:target="onUpdateTranslation">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                        <span><?php echo e(__('Save Changes')); ?></span>
                                    </span>
                                </button>
                            </div>

                            <table class="table align-items-center mb-0">
                                <tbody>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Default Text')); ?></th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2"><?php echo e(__('Translation')); ?></th>
                                        <th class="text-secondary opacity-7"></th>
                                    </tr>
                                    <?php if( !empty($translations) ): ?>

                                        <?php $__currentLoopData = $translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td class="align-middle"><input type="text" class="form-control" wire:model.defer="translations.<?php echo e($index); ?>.key" readonly></td>
                                            <td class="align-middle"><input type="text" class="form-control" wire:model.defer="translations.<?php echo e($index); ?>.value" wire:ignore></td>
                                            <td class="align-middle"><a title="Delete" class="float-end" href="javascript:;" wire:click="onDeleteTranslation(<?php echo e($translation['id']); ?>)"><i class="fas fa-trash"></i></a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>
                                        <tr><td class="align-middle"><?php echo e(__('No record found')); ?></td></tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </form>
                        
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Begin::Add New Translation -->
    <div class="modal fade" id="addNewTranslation" tabindex="-1" role="dialog" aria-labelledby="addNewTranslationLabel" aria-hidden="true">
       <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
             <div class="modal-header">
                <h5 class="modal-title" id="addNewTranslationModalLabel"><?php echo e(__('Add New Translation')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
             </div>
             <div class="modal-body">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.translations.add-new-translation', ['lang_id' => Route::current()->parameter('lang_id') ])->html();
} elseif ($_instance->childHasBeenRendered('QWVPe8u')) {
    $componentId = $_instance->getRenderedChildComponentId('QWVPe8u');
    $componentTag = $_instance->getRenderedChildComponentTagName('QWVPe8u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QWVPe8u');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.translations.add-new-translation', ['lang_id' => Route::current()->parameter('lang_id') ]);
    $html = $response->html();
    $_instance->logRenderedChild('QWVPe8u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             </div>
          </div>
       </div>
    </div>
    <!-- End::Add New Translation -->

</div>
<?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/settings/translations/edit-translation.blade.php ENDPATH**/ ?>