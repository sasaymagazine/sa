<?php switch( $advertisement->area3_align ):
    case ('left'): ?>
		<div class="area3 d-flex justify-content-start" style="margin:<?php echo e($advertisement->area3_margin); ?>px;">
			<?php echo $advertisement->area3; ?>

		</div>

    <?php break; ?>

    <?php case ('right'): ?>
		<div class="area3 d-flex justify-content-end" style="margin:<?php echo e($advertisement->area3_margin); ?>px;">
			<?php echo $advertisement->area3; ?>

		</div>
    <?php break; ?>

    <?php default: ?>
		<div class="area3 d-flex justify-content-center" style="margin:<?php echo e($advertisement->area3_margin); ?>px;">
			<?php echo $advertisement->area3; ?>

		</div>
<?php endswitch; ?><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/components/frontend/advertisement/area3.blade.php ENDPATH**/ ?>