<?php

namespace App\Http\Livewire\Frontend\Install;

use Livewire\Component;
use App\Models\Install;
class Welcome extends Component
{
    public function render()
    {
        return view('livewire.frontend.install.welcome');
    }
}
